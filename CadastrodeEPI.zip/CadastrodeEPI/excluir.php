<?php

require_once 'conexao.php';

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);
    
    $sql = "DELETE FROM Cadastrar WHERE id = ?";
    
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        header("Location: consultar.php?status=excluido_sucesso");
        exit();
    } else {
        echo "Erro ao excluir: " . $stmt->error;
    }
    
    $stmt->close();
}

$conexao->close();

header("Location: consultar.php");
exit();
?>