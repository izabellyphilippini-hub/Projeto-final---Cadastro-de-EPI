<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de EPI/EPC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

    <style>
         body {
            background-color: rgb(77, 162, 241);
            min-height: 100vh;
            margin: 0;
        }
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type=number] {
            -moz-appearance: textfield;
        }

        .form-label {
            text-align: left;
            display: block;

            font-weight: 500;
        }
    </style>
</head>

<body>
    <div class="container d-flex justify-content-center align-items-center my-5 min-vh-100">
        <div class="card text-center" style="width: 25rem;">
            <div class="card-body">
                <h1 class="card-title">
                    <i class="bi bi-cone-striped"></i>
                </h1>
                <h5 class="card-title mb-4">Cadastre o EPI.</h5>

                <form action="salvar_cadastro.php" method="POST" class="needs-validation" novalidate>

                    <input type="number" name="ca_number" placeholder="Número do CA " class="form-control mb-3"
                        required>

                    <input type="text" name="nome_epi" placeholder="Nome do EPI" class="form-control mb-3" required>

                    <input type="text" name="nome_empresa" placeholder="Nome da Empresa" class="form-control mb-3"
                        required>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="vencimentoCa" class="form-label">Vencimento do CA</label>
                            <input type="date" name="date_ca" id="vencimentoCa" class="form-control" required>
                        </div>

                        <div class="col-md-6">
                            <label for="vencimentoEpi" class="form-label">Vencimento do EPI</label>
                            <input type="date" name="date_epi" id="vencimentoEpi" class="form-control" required>
                        </div>
                    </div>

                    <input type="number" name="quantidade" placeholder="Quantidade" class="form-control mb-3" required>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="dataCompra" class="form-label">Data da Compra</label>
                            <input type="date" name="date_compra" id="dataCompra" class="form-control" required>
                        </div>

                        <div class="col-md-6">
                            <label for="dataRecebimento" class="form-label">Data do Recebimento</label>
                            <input type="date" name="date_recebimento" id="dataRecebimento" class="form-control"
                                required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="formFile" class="form-label">Nota da Compra</label>
                        <input class="form-control" type="file" name="nota_compra" id="formFile" required>
                    </div>

                    <label for="celular" class="form-label">Número da Empresa (com DDD):</label>
                    <input class="form-control" type="tel" id="celular" name="celular"
                        placeholder="Número do fornecedor" maxlength="15" required>

                    <div class="d-grid gap-2 d-md-flex justify-content-center mt-4">
                    <button type="submit" class="btn btn-primary">
                        Cadastrar <i class="bi bi-box-arrow-in-up"></i>
                    </button>

                     <a href="index.php" class="btn btn-secondary">
                        Voltar <i class="bi bi-arrow-counterclockwise"></i>
                    </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')

            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        form.classList.add('was-validated')
                    }, false)
                })
        })()
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>

</body>

</html>