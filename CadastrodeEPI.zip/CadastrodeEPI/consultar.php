<?php

require_once 'conexao.php';

$sql = "SELECT id, ca, nome, empresa, vencimento_ca, vencimento_epi, quantidade, data_compra, data_recebimento, telefone FROM Cadastrar ORDER BY id DESC";

$resultado = $conexao->query($sql);

if (!$resultado) {
    die("Erro ao buscar dados do MySQL: " . $conexao->error);
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de EPI/EPC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    
    <style>

        body {
            background-color: rgb(77, 162, 241);
            min-height: 100vh;
            margin: 0;
        }
        
        .container {
            padding-top: 50px;
            padding-bottom: 50px;
        }

        .table-responsive {
            max-height: 70vh; 
            overflow-y: auto;
        }
        
        .table th {
            position: sticky;
            top: 0;
            background: #f8f9fa;
            z-index: 10;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2 class="text-center text-white mb-4">Itens Cadastrados</h2>

        <div class="mb-3">
    <input type="text" id="filtroPesquisa" class="form-control" placeholder="Digite para filtrar por CA, EPI ou Empresa...">
</div>

        
        <div class="d-flex justify-content-end mb-3">
            <a href="cadastrar.php" class="btn btn-success me-2"><i class="bi bi-plus-circle"></i> Novo Cadastro</a>
            <a href="index.php" class="btn btn-secondary"><i class="bi bi-arrow-counterclockwise"></i> Voltar</a>
        </div>

        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table table-hover table-striped">
                <thead class="table-light">
                    <tr>
                        <th>CA</th>
                        <th>EPI</th>
                        <th>Empresa</th>
                        <th>Venc. CA</th>
                        <th>Venc. EPI</th>
                        <th>Qtd.</th>
                        <th>Compra</th>
                        <th>Recebimento</th>
                        <th>Contato</th>
                        <th>Editar | Excluir</th>
                    </tr>
                </thead>
                <tbody id="lista-epis">
                    <?php

                    if ($resultado->num_rows > 0) {

                        while ($row = $resultado->fetch_assoc()) {

                            $vencimento_ca = strtotime($row['vencimento_ca']);
                            $vencimento_epi = strtotime($row['vencimento_epi']);
                            $hoje = time();
                            
                            $classe_alerta = '';
                            if ($vencimento_ca < $hoje || $vencimento_epi < $hoje) {
                                $classe_alerta = 'table-danger';
                            } elseif (($vencimento_ca - $hoje) < (30 * 24 * 60 * 60) || ($vencimento_epi - $hoje) < (30 * 24 * 60 * 60)) {
                                $classe_alerta = 'table-warning';
                            }
                            
                            echo "<tr class='$classe_alerta'>";
                            echo "<td>" . htmlspecialchars($row['ca']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['nome']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['empresa']) . "</td>";
                            echo "<td>" . htmlspecialchars(date('d/m/Y', $vencimento_ca)) . "</td>";
                            echo "<td>" . htmlspecialchars(date('d/m/Y', $vencimento_epi)) . "</td>";
                            echo "<td>" . htmlspecialchars($row['quantidade']) . "</td>";
                            echo "<td>" . htmlspecialchars(date('d/m/Y', strtotime($row['data_compra']))) . "</td>";
                            echo "<td>" . htmlspecialchars(date('d/m/Y', strtotime($row['data_recebimento']))) . "</td>";
                            echo "<td>" . htmlspecialchars($row['telefone']) . "</td>";
                            echo "<td>
                                <a href='editar.php?id={$row['id']}' class='btn btn-sm btn-info me-1'><i class='bi bi-pencil'></i></a>
                                <a href='excluir.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick=\"return confirm('Tem certeza que deseja excluir este item?');\"><i class='bi bi-trash'></i></a>
                            </td>";
                            echo "</tr>";
                        }
                    } else {

                        echo "<tr><td colspan='11' class='text-center'>Nenhum EPI/EPC cadastrado.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>

        <script>
    document.getElementById('filtroPesquisa').addEventListener('keyup', function() {
        var filtro = this.value.toUpperCase(); 
        
        var tbody = document.getElementById('lista-epis');
        
        var linhas = tbody.getElementsByTagName('tr');

        for (var i = 0; i < linhas.length; i++) {
            var linha = linhas[i];

            var ca = linha.getElementsByTagName('td')[0];
            var nome = linha.getElementsByTagName('td')[1];
            var empresa = linha.getElementsByTagName('td')[2];

            var mostrarLinha = false;
            
            if (ca) {
                if (ca.textContent.toUpperCase().indexOf(filtro) > -1) {
                    mostrarLinha = true;
                }
            }
            if (nome) {
                if (nome.textContent.toUpperCase().indexOf(filtro) > -1) {
                    mostrarLinha = true;
                }
            }
            if (empresa) {
                if (empresa.textContent.toUpperCase().indexOf(filtro) > -1) {
                    mostrarLinha = true;
                }
            }
            
            if (mostrarLinha) {
                linha.style.display = "";
            } else {
                linha.style.display = "none";
            }
        }
    });
</script>
</body>
</html>
<?php

$conexao->close();
?>