create	database CadastroEPI;

use CadastroEPI;

CREATE TABLE Cadastrar (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ca VARCHAR(10) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    empresa VARCHAR(100) NOT NULL,
    vencimento_ca DATE NOT NULL,
    vencimento_epi DATE NOT NULL,
    quantidade INT(11) NOT NULL,
    data_compra DATE NOT NULL,
    data_recebimento DATE NOT NULL,
    telefone VARCHAR(15) NOT NULL
);
USE CadastroEPI;

ALTER TABLE Cadastrar
DROP COLUMN site_empresa;