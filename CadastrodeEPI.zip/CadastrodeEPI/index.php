<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Início</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="style.css"/>
</head>

<body>
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card text-center" style="width: 18rem;">
            <div class="card-body">
                <h1 class="card-title">
                    <i class="bi bi-cone-striped"></i>
                </h1>
                <h5 class="card-title">Cadastro de EPI</h5>
                <form class="card-text" style="font-size: 0.8rem;">
                    <p>Forma fácil e rápida de cadastrar e consultar os
                    EPIs da sua empresa.</p>
                    <a href="cadastrar.php" class="btn btn-primary">Cadastrar <i class="bi bi-box-arrow-in-up"></i>
                    </a>
                    <a href="consultar.php" class="btn btn-secondary">Consultar <i class="bi bi-box-arrow-in-left"></i>
                    </a>
                </form>
            </div>
        </div>
    </div>
</body>

</html>

<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>