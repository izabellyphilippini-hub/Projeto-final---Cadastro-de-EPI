<?php

$servidor = "localhost";
$usuario = "root";
$senha = "root";
$banco = "cadastroepi";
$porta = 3306;

$conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);

if ($conexao->connect_error) {

    die("Falha na Conexão: " . $conexao->connect_error);
}

$conexao->set_charset("utf8mb4");

?>