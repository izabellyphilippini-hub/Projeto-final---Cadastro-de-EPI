<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'conexao.php'; 

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$ca = htmlspecialchars($_POST['ca_number']);
$nome = htmlspecialchars($_POST['nome_epi']);
$empresa = htmlspecialchars($_POST['nome_empresa']);
$venc_ca = $_POST['date_ca'];
$venc_epi = $_POST['date_epi'];
$quantidade = intval($_POST['quantidade']);
$data_compra = $_POST['date_compra'];
$data_receb = $_POST['date_recebimento'];
$telefone = htmlspecialchars($_POST['celular']);

$sql = "";
$bind_string = "";
$bind_vars = [];
$redirecionamento = "";

if ($id > 0) {
    $sql = "UPDATE Cadastrar SET 
                ca = ?, 
                nome = ?, 
                empresa = ?, 
                vencimento_ca = ?, 
                vencimento_epi = ?, 
                quantidade = ?, 
                data_compra = ?, 
                data_recebimento = ?, 
                telefone = ? 
            WHERE id = ?";

    $bind_string = "sssssissi";
    $bind_vars = [&$ca, &$nome, &$empresa, &$venc_ca, &$venc_epi, &$quantidade, &$data_compra, &$data_receb, &$telefone, &$id];
    $redirecionamento = "consultar.php?status=edicao_sucesso";

} else {

    $sql = "INSERT INTO Cadastrar (ca, nome, empresa, vencimento_ca, vencimento_epi, quantidade, data_compra, data_recebimento, telefone) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $bind_string = "sssssiss"; 
    $bind_vars = [&$ca, &$nome, &$empresa, &$venc_ca, &$venc_epi, &$quantidade, &$data_compra, &$data_receb, &$telefone];
    $redirecionamento = "consultar.php?status=cadastro_sucesso";
}

$stmt = $conexao->prepare($sql);

if ($stmt === false) {

    die("Erro ao preparar a consulta SQL: " . $conexao->error);
}

call_user_func_array(array($stmt, 'bind_param'), array_merge([$bind_string], $bind_vars));

if ($stmt->execute()) {
    header("Location: $redirecionamento"); 
    exit();
} else {
    echo "Erro na operação: " . $stmt->error;
}

$stmt->close();
$conexao->close();
?>